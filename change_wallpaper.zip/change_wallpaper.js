//by wujun 20130711
var wrapperTimeOut;
var PIC_TYPE_DATA_CACHE_EXPIRATION = 7 * 24 * 60 * 60 * 1000;
chrome.send("getWallpaperSetting");
var curTime = +new Date();
if (!localStorage["picTypeList_lastTime"] || !localStorage["picTypeList"] || (curTime - parseFloat(localStorage['picTypeList_lastTime'])) > PIC_TYPE_DATA_CACHE_EXPIRATION) {
  chrome.send("downloadWallpaperInfo", ["http://cdn.apc.360.cn/index.php?c=WallPaper&a=getAllCategoriesV2&from=360chrome"]);
} else {
  var dataList = JSON.parse(localStorage["picTypeList"]).data;
  loadPicTypes(dataList);
}
errorClose(); //can set the image list background info is loading

// loading图铺满整个主体区域
function resetCover() {
  var cover = document.querySelector('#cover');
  cover.style.width = '706px';
  cover.style.height = '242px';
  cover.style.left = '0px';
  cover.style.top = '36px';
  cover.style.paddingTop = '160px';
  cover.style.marginTop = '16px';
  cover.style.marginLeft = '16px';
  cover.style.display = "block";
  cover.style.fontSize = '16px';

  var loading_pic = cover.querySelector('.loading_pic');
  loading_pic.style.width = '60px';
  loading_pic.style.height = '60px';
}

// loading图铺满某个指定区域
function setCover(currentNode) {
  var getoffset = function(e) {
    var t = e.offsetTop;
    var l = e.offsetLeft;
    while (e = e.offsetParent) {
      t += e.offsetTop;
      l += e.offsetLeft;
    }
    var rec = new Array(1);
    rec[0] = t;
    rec[1] = l;
    return rec
  };
  var cover = document.querySelector('#cover');
  var pOffset = getoffset(currentNode);
  cover.style.display = "block";
  cover.style.width = currentNode.clientWidth + 'px';
  // loading图加文字的高度大概为72px
  var paddingTop = (currentNode.clientHeight - 72) / 2;
  cover.style.height = (currentNode.clientHeight - paddingTop) + 'px';
  cover.style.left = pOffset[1] + 'px';
  cover.style.top = pOffset[0] + 'px';
  cover.style.paddingTop = paddingTop + 'px';
  cover.style.marginLeft = 0;
  cover.style.fontSize = '14px';

  var loading_pic = cover.querySelector('.loading_pic');
  loading_pic.style.width = '48px';
  loading_pic.style.height = '48px';
}

function getPicListByTypeID(cid, start, count) {
  resetCover();
  $("loading_info").innerHTML = "正在加载壁纸...";
  if (wrapperTimeOut) {
    clearTimeout(wrapperTimeOut);
  }
  wrapperTimeOut = setTimeout(function() {
    reportError();
  }, 8000);
  currentType = cid;
  var s = (typeof(start) == "number") ? start : 0;
  if (!s) {
    var imglistDiv = document.querySelector("#imglist");
    imglistDiv.innerHTML = "";
  }
  var c = (typeof(count) == "number" && count > 0) ? count : 20;
  var url = "http://wallpaper.apc.360.cn/index.php?c=WallPaper&a=getAppsByOrder&order=create_time&start=" + s + "&count=" + c + "&from=360chrome";
  if (cid) {
    url = "http://wallpaper.apc.360.cn/index.php?c=WallPaper&a=getAppsByCategory&cid=" + cid + "&start=" + s + "&count=" + c + "&from=360chrome";
  }
  chrome.send("downloadWallpaperInfo", [url]);
}

function getWrapperHistory() {
  resetCover();
  $("loading_info").innerHTML = "正在加载使用过的壁纸...";
  if (wrapperTimeOut) {
    clearTimeout(wrapperTimeOut);
  }
  wrapperTimeOut = setTimeout(function() {
    reportError();
  }, 8000);
  var imglistDiv = document.querySelector("#imglist");
  imglistDiv.innerHTML = "";
  chrome.send('getWallpaperList');
}

function getPersonalWrapper() {
  resetCover();
  $("loading_info").innerHTML = "正在加载使用过的个性壁纸...";
  if (wrapperTimeOut) {
    clearTimeout(wrapperTimeOut);
  }
  wrapperTimeOut = setTimeout(function() {
    reportError();
  }, 8000);
  var imglistDiv = document.querySelector("#imglist");
  imglistDiv.innerHTML = "";
  jsonp({
    url: "http://api.chrome.360.cn/skin/rec?callback=loadPersonalWrapper",
    callbackName: 'loadPersonalWrapper',
    onsuccess: function(data) {
      clearTimeout(wrapperTimeOut);
      if (data) {
        loadPersonalWrapper(data);
        var cacheData = {
          'lastTime': +new Date(),
          'data': data
        };
        localStorage['personalCache'] = JSON.stringify(cacheData);
      }
    },
    onerror: function() {

    }
  });
}

function loadPersonalWrapper(pData) {
  clearTimeout(wrapperTimeOut);
  errorClose();
  var imglistDiv = document.querySelector("#imglist");
  imglistDiv.innerHTML = "";
  /*if (pData && pData.length > 0) {
      for (var i = 0; i < pData.length; i++) {
          var c3 = document.createElement("div");
          c3.className = "c3";

          var itemImage = document.createElement("img");
          itemImage.src = pData[i].thumb_url;
          itemImage.setAttribute("url", pData[i].url);

          var itemTips = document.createElement("span");
          itemTips.className = "imgTips";
          itemTips.innerHTML = "设为壁纸";
          c3.appendChild(itemImage);
          c3.appendChild(itemTips);

          $("imglist").appendChild(c3);
      }
  }*/
  var defaultList = '<div class="c3"><img wid="kbkcbegiadbbknmphhihinklohdnogph" src="chrome://change-wallpaper/images/jisu8.png" crxurl="http://download.chrome.360.cn/skin/jisu8.crx"><span class="imgTips">极速8</span></div>';
  defaultList += '<div class="c3"><img wid="default" src="chrome://change-wallpaper/images/jisu7_default.png"><span class="imgTips">极速7</span></div>';
  defaultList += '<div class="c3"><img wid="opljjflfcohaglffbobpdpkihngjibij" src="chrome://change-wallpaper/images/jisu8_blue.png" crxurl="http://download.chrome.360.cn/skin/jisu8_blue.crx"><span class="imgTips">蓝色悦动</span></div>';
  defaultList += '<div class="c3"><img wid="hfgbcplpfmimdkgkchnbkgenafblnook" src="chrome://change-wallpaper/images/jisu8_black.png" crxurl="http://download.chrome.360.cn/skin/jisu8_black.crx"><span class="imgTips">冷月</span></div>';
  defaultList += '<div class="c3"><img wid="npljkjaljfofdhjfbemchngdncakmfgh" src="chrome://change-wallpaper/images/jisu8_edge.png" crxurl="http://download.chrome.360.cn/skin/edge.crx"><span class="imgTips">Edge</span></div>';
  defaultList += '<div class="c3"><img wid="hffiefgphpmpnkfpbkpklibphhkgoojd" src="chrome://change-wallpaper/images/jisu8_pink.png" crxurl="http://download.chrome.360.cn/skin/jisu8_pink.crx"><span class="imgTips">棉花糖</span></div>';
  defaultList += '<div class="c3"><img wid="elnacedabailodhgdljifcdmablecooh" src="chrome://change-wallpaper/images/jisu7_theme2.png" crxurl="http://download.chrome.360.cn/skin/jisu7_theme2.crx"><span class="imgTips">纯色之美</span></div>';
  defaultList += '<div class="c3"><img wid="geekkoedlankmgbjiogodoaibieloiep" src="chrome://change-wallpaper/images/jisu5.0.png" crxurl="http://download.chrome.360.cn/skin/jisu5.0.crx"><span class="imgTips">chrome经典</span></div>';
  imglistDiv.innerHTML += defaultList;

  var moreSkin = document.createElement("a");
  moreSkin.id = "moreSkin";
  moreSkin.setAttribute("target", "_blank");
  moreSkin.addEventListener("click", function() {
    var link = "https://skin.chrome.360.cn/webstore/category/0";
    chrome.send("openURL", [link]);
  });
  imglistDiv.appendChild(moreSkin);
}

function errorClose() {
  $("error_info").style.display = "none";
  $("cover").style.display = "none";
  $("imglist").classList.remove("error");
  document.querySelector("#setting-container .c_foot").style.pointerEvents = "auto";
}

function hiddeMoreMenu() {
  var targetNode = event.target;
  var menuMore = $("menu-more");
  var moreli = $("limore");
  //setTimeout(function () {
  if (!menuMore.contains(targetNode) && targetNode.id != "menu-more" && targetNode.id != "limore" && !moreli.contains(targetNode)) {
    $("menu-more").classList.add("hidden");
  }
  //}, 150);
}
(function() {
  $("setting-container").addEventListener("click", hiddeMoreMenu);
  $("setting-container").addEventListener("mousemove", hiddeMoreMenu);
  $("setting-container").addEventListener("mouseover", hiddeMoreMenu);

  if (loadTimeData.getString("thumbOpValue") != localStorage.thumbOpValue)
    localStorage.thumbOpValue = loadTimeData.getString("thumbOpValue");
  var cachedRangeValue = localStorage.thumbOpValue ? localStorage.thumbOpValue : 15;
  var thumbnailOpactiyRange = $("thumbnailOpacityRange");
  thumbnailOpactiyRange.value = cachedRangeValue;
  $("opacityBar").style.width = (cachedRangeValue / 100) * (thumbnailOpactiyRange.clientWidth - 0) + "px";
  var opacityBarValue = $("opacityBarValue");
  $("opacityBarValue-txt").innerText = cachedRangeValue + "%";
  opacityBarValue.style.left = thumbnailOpactiyRange.offsetLeft + (cachedRangeValue / 100) * (thumbnailOpactiyRange.clientWidth - 17) - opacityBarValue.clientWidth / 2 + 9 + "px";
  opacityBarValue.style.top = thumbnailOpactiyRange.offsetTop - thumbnailOpactiyRange.clientHeight - opacityBarValue.clientHeight + 0 + "px";

  $("wrapperHistory").addEventListener("click", function(e) {
    var liList = document.querySelectorAll("#topmenu li");
    for (var t = 0; t < liList.length; t++) {
      if (liList[t].classList.contains("menu_active")) {
        liList[t].classList.remove("menu_active");
      }
    }
    this.classList.add("menu_active");
    getWrapperHistory();
    localStorage["picLastType"] = "o";
  });

  $("selectLocalPic").addEventListener("click", function(e) {
    chrome.send("selectWallpaperFile");
  });

  $("resetToDefaultWapper").addEventListener("click", function(e) {
    chrome.send('setWallpaperType', ['no']);
    var currentWrapper = localStorage["currentWrapper"] ? JSON.parse(localStorage["currentWrapper"]) : {};
    currentWrapper.type = "";
    currentWrapper.url = "";
    localStorage["currentWrapper"] = JSON.stringify(currentWrapper);
  });

  $("selectWallpaperType").addEventListener("change", function(e) {
    chrome.send("setWallpaperType", [$("selectWallpaperType").value]);
  });

  $("thumbnailOpacityRange").addEventListener("mouseup", function() {
    localStorage.thumbOpValue = this.value;
    chrome.send('saveOpacity', [this.value]);
  });

  $("thumbnailOpacityRange").addEventListener("change", function() {
    $("opacityBar").style.width = (this.value / 100) * (this.clientWidth - 0) + "px";
    var opacityBarValue = $("opacityBarValue");
    $("opacityBarValue-txt").innerText = this.value + "%";
    opacityBarValue.style.left = this.offsetLeft + (this.value / 100) * (this.clientWidth - 17) - opacityBarValue.clientWidth / 2 + 9 + "px";
    opacityBarValue.style.top = this.offsetTop - this.clientHeight - opacityBarValue.clientHeight + 0 + "px";

  });

  $("error_close").addEventListener("click", errorClose);
  $("error_ok").addEventListener("click", errorClose);

  $("imglist").onscroll = function() {
    if ($("wrapperHistory").classList.contains('menu_active')) return;
    $("menu-more").classList.add("hidden");
    var scrollH = this.clientHeight + this.scrollTop;
    var realH = this.scrollHeight;
    if ((scrollH - realH) >= -2) { //at the end of scroll bar
      var imgLen = document.querySelectorAll("#imglist img").length;
      getPicListByTypeID(currentType, imgLen, 20);
    }
  };
  //event delegate should be faster ...
  $("imglist").addEventListener("click", function(e) {
    e = e || window.event;
    var targetNode = e.target || e.srcElement;
    if (targetNode.nodeName.toLowerCase() === 'img') {
      errorClose();

      var imgurl = targetNode.getAttribute("url");
      var wid = targetNode.getAttribute("wid");
      var currentType = "",
        currentUrl = "";
      var crxurl = targetNode.getAttribute("crxurl");

      if (wrapperTimeOut) {
        clearTimeout(wrapperTimeOut);
      }

      if (imgurl) {
        // 点击壁纸
        if ($("lipersonal").classList.contains("menu_active")) {
          setCover(targetNode.parentNode);
        } else {
          resetCover();
          wrapperTimeOut = setTimeout(function() {
            reportError();
          }, 15000);
        }
        $("loading_info").innerHTML = "正在切换壁纸...";
        document.querySelector("#setting-container .c_foot").style.pointerEvents = "none";

        chrome.send("downloadWallpaper", [imgurl]);
        currentType = localStorage["picLastType"];
        currentUrl = imgurl;
      } else if (wid && $("wrapperHistory").classList.contains("menu_active")) {
        // 点击历史记录
        if (wid == "default") wid = "";
        chrome.send('selectWallpaper', [wid]);
        currentType = "h";
      } else if (wid && $("lipersonal").classList.contains("menu_active")) {
        setCover(targetNode.parentNode);
        $("loading_info").innerHTML = "正在切换壁纸...";
        document.querySelector("#setting-container .c_foot").style.pointerEvents = "none";
        if (crxurl) {
          // 点击在线壁纸
          chrome.send("downloadCrx", [wid, crxurl]);
        } else {
          // 点击本地壁纸
          if (wid == "default") wid = "";
          chrome.send('setTheme', [wid]);
        }
        currentType = "p";
      }

      var currentWrapper = localStorage["currentWrapper"] ? JSON.parse(localStorage["currentWrapper"]) : {};
      currentWrapper.type = currentType;
      currentWrapper.url = currentUrl;
      localStorage["currentWrapper"] = JSON.stringify(currentWrapper);
    }
    if (targetNode.classList.contains("wp_set")) {
      var imgDiv = targetNode.parentNode.previousSibling;
      var imgurl = imgDiv.getAttribute("url");
      if (imgurl) {
        chrome.send('installOSWallpaper', [imgurl]);
        resetCover();
        $("loading_info").innerHTML = "正在设置桌面背景...";
        document.querySelector("#setting-container .c_foot").style.pointerEvents = "none";
        if (wrapperTimeOut) {
          clearTimeout(wrapperTimeOut);
        }
        wrapperTimeOut = setTimeout(function() {
          reportError();
        }, 15000);
      }
    }
  });
  // $("shareWapper").addEventListener("click", function(e) {
  //   var currentWrapper = localStorage["currentWrapper"] ? JSON.parse(localStorage["currentWrapper"]) : {};
  //   var c_type = currentWrapper.type ? currentWrapper.type : "";
  //   var c_url = currentWrapper.url ? currentWrapper.url : "";
  //   if (c_url) {
  //     c_url = c_url.replace("\/__85", "\/1024_768_85");
  //   }
  //   chrome.send("sharetoweibo", [c_type, c_url]);
  // });
})();

//codes in newtab.js

function loadWallpaper(args) {
  if (args && args.length == 5) {
    var installed = args[0];
    var x = args[1];
    var y = args[2];
    var width = args[3];
    var height = args[4];
    document.querySelector("html").style.backgroundImage = "url(chrome://theme/IDR_THEME_NTP_BACKGROUND?" + Date.now() + ")";
    if (installed == true) {
      updateWallpaperOffset(x, y);
    }
    if (width != 0 && height != 0) {
      document.querySelector("html").style.backgroundSize = width + 'px ' + height + 'px';
    }
  }
}

function updateWallpaperOffset(x, y) {
  document.querySelector("html").style.backgroundPosition = (-x) + "px " + (-y) + "px";
}

function isMD5(s) {
  var patrn = /^[a-fA-F0-9]{32}$/;
  if (!patrn.exec(s)) return false
  return true
}

function getWallpaperList(walllist) {
  //        console.log(walllist);
  clearTimeout(wrapperTimeOut);
  errorClose();
  var imglistDiv = document.querySelector("#imglist");
  imglistDiv.innerHTML = "";
  if (walllist && walllist.length > 0) {
    var len = walllist.length;
    var str = "";
    for (var i = 0; i < len; i++) {
      if (walllist[i].id) {
        var skin = !isMD5(walllist[i].id) ? " class = 'skin' " : "";
        if (walllist[i].id == 'mbbnlnanfdfhbbbafokaikpnhgmbmapp' || walllist[i].id == 'elnacedabailodhgdljifcdmablecooh' || walllist[i].id == 'geekkoedlankmgbjiogodoaibieloiep' || walllist[i].id == 'kbkcbegiadbbknmphhihinklohdnogph' || walllist[i].id == 'opljjflfcohaglffbobpdpkihngjibij' || walllist[i].id == 'hfgbcplpfmimdkgkchnbkgenafblnook' || walllist[i].id == 'ckhdegagkacogoabmfnhiahjnlpfbgpn' || walllist[i].id == 'hffiefgphpmpnkfpbkpklibphhkgoojd' || walllist[i].id == 'npljkjaljfofdhjfbemchngdncakmfgh') {
          skin = '';
        }
        str += "<div class='c3'><img wid='" + walllist[i].id + "' " + skin + " src='chrome://customwallpaper/" + walllist[i].id + "' /><span class='imgTips'>设为壁纸</span></div>";
      } else
        str += "<div class='c3'><img wid='default' src='chrome://change-wallpaper/images/jisu7_default.png' /><span class='imgTips'>设为壁纸</span></div>";
    }
    imglistDiv.innerHTML = str;
  } else {
    imglistDiv.innerHTML = "<div style='width: 100%;line-height: 432px;text-align: center;vertical-align: middle;'>您还没有更换过壁纸，赶快试试吧～</div>";
  }
}

function getWallpaperSetting(wallpaperSetting) {
  var selectW = $("selectWallpaperType");
  var optionLen = selectW.options.length;
  for (var i = 0; i < optionLen; i++) {
    if (selectW.options[i].value == wallpaperSetting.walltype) {
      selectW.options[i].selected = true;
      break;
    }
  }
}

function applySuccess() {
  $("cover").style.display = "none";
  var starDetails = document.querySelectorAll(".star-detail,.star-special-item");
  starDetails.foreach(function(e, i, a) {
    var loading = e.querySelector(".star-bg-loading");
    if (loading) e.removeChild(loading);
  });
  document.querySelector("#setting-container .c_foot").style.pointerEvents = "auto";
  clearTimeout(wrapperTimeOut);
  var searchTypes = document.querySelectorAll(".search-cat a");
  searchTypes.foreach(function(e, i, a) {
    e.classList.add("haswrapper");
  });
  $("setting").classList.add("setting-glass");
  $("recently-closed-menu-button").classList.add("haswrapper");
}

function reportError(src, err) {
  //display the error tips
  $("error_info").style.display = "block";
  var errStr = "网络异常，加载失败！<br>请检查您的网络连接。";
  switch (err) {
    case "InvalidImage":
      errStr = "图片格式错误，无法设置为壁纸！";
      break;
    case "FailInstall":
      errStr = "拷贝图片到临时缓冲目录失败！";
      break;
    case "FailRead":
      errStr = "打开本地文件失败！";
      break;
    default:
  }
  $("error_body").innerHTML = errStr;
  document.querySelector("#setting-container .c_foot").style.pointerEvents = "auto";
}

function failDownWallpaper(url) {
  $("error_info").style.display = "block";
  $("error_body").innerHTML = "网络异常，设置失败！<br>请检查您的网络连接。";
}

Array.prototype.rnd = function() {
  this.sort(function() {
    return 0.5 > Math.random();
  });
  return this;
}

function createElementWithClassName(type, className) {
  var elm = document.createElement(type);
  elm.className = className;
  return elm;
}

function getImgContainers() {
  var divList1 = [createElementWithClassName("div", "c1"), createElementWithClassName("div", "c2"), createElementWithClassName("div", "c1")].rnd();
  var divList3 = [createElementWithClassName("div", "c1"), createElementWithClassName("div", "c2"), createElementWithClassName("div", "c1")].rnd();
  var divList2 = [createElementWithClassName("div", "c2"), createElementWithClassName("div", "c1"), createElementWithClassName("div", "c1")].rnd();
  var divList4 = [createElementWithClassName("div", "c2"), createElementWithClassName("div", "c1"), createElementWithClassName("div", "c1")].rnd();
  return divList1.concat(divList2, divList3, divList4);;
}

function createImgWithInfo(info, classN) {
  var itemE = document.createElement("img");
  itemE.id = info.id;
  var nsrc = info.url;
  if (classN == "c1")
    nsrc = nsrc.replace("r\/__85", "m\/172_93_");
  else if (classN == "c2")
    nsrc = nsrc.replace("r\/__85", "m\/350_192_");
  itemE.setAttribute("src", nsrc);
  itemE.setAttribute("alt", info.utag);
  var bigimg = "img_" + screen.width + "_" + screen.height;
  var availUrl = info[bigimg] ? info[bigimg] : info.url;
  itemE.setAttribute("url", availUrl);
  return itemE;
}
var PWRAPPER_DATA_CACHE_EXPIRATION = 7 * 24 * 60 * 60 * 1000;

function loadPicTypes(dataList) {
  var typeList = dataList;
  var dataLen = typeList.length;
  var topMenu = document.querySelector("#topmenu ul");
  var moreMenu = $("menu-more");
  topMenu.innerHTML = "";
  moreMenu.innerHTML = "";

  var personalElement = document.createElement("li");
  personalElement.id = "lipersonal";
  personalElement.style.display = 'none';
  var aPersonalElement = document.createElement("a");
  aPersonalElement.href = "javascript:void(0);";
  aPersonalElement.innerText = "主题";
  personalElement.appendChild(aPersonalElement);
  personalElement.addEventListener("click", function(e) {
    var liList = document.querySelectorAll("#topmenu li");
    for (var t = 0; t < liList.length; t++) {
      if (liList[t].classList.contains("menu_active")) {
        liList[t].classList.remove("menu_active");
      }
    }
    $("wrapperHistory").classList.remove("menu_active");
    this.classList.add("menu_active");
    localStorage["picLastType"] = "p";
    var imglistDiv = document.querySelector("#imglist");
    imglistDiv.innerHTML = "";
    var curTime = +new Date();
    var personalData = null;
    if (localStorage["personalCache"]) personalData = JSON.parse(localStorage["personalCache"]);
    if (!personalData || !personalData.data || (curTime - parseFloat(personalData.lastTime)) > PWRAPPER_DATA_CACHE_EXPIRATION)
      getPersonalWrapper();
    else {
      var personalCache = JSON.parse(localStorage['personalCache']);
      loadPersonalWrapper(personalCache.data);
    }
  });
  topMenu.appendChild(personalElement)
    // personalElement.click();

  var firstMenuItem = {
    id: 0,
    name: "最新"
  };
  typeList.unshift(firstMenuItem);
  dataLen++;
  var moreCount = 9;
  for (var j = 0; j < dataLen; j++) {
    var aElement = document.createElement("a");
    aElement.href = "javascript:void(0);";
    if (j < moreCount)
      aElement.innerText = (typeList[j].name.length < 4) ? typeList[j].name : typeList[j].name.substring(0, 2);
    else
      aElement.innerText = typeList[j].name;

    var liElement = document.createElement("li");
    liElement.onclick = (function(j) {
      return function() {
        var liList = document.querySelectorAll("#topmenu li");
        for (var t = 0; t < liList.length; t++) {
          if (liList[t].classList.contains("menu_active")) {
            liList[t].classList.remove("menu_active");
          }
        }
        $("wrapperHistory").classList.remove("menu_active");
        this.classList.add("menu_active");
        if (j >= moreCount) liList[moreCount + 1].classList.add("menu_active");
        getPicListByTypeID(typeList[j].id);
        localStorage["picLastType"] = typeList[j].id;
      };
    })(j);

    liElement.appendChild(aElement);

    if (j < moreCount)
      topMenu.appendChild(liElement);
    else
      moreMenu.appendChild(liElement);

    if (j == 0) {
      liElement.click();
    }
  }

  var moreElement = document.createElement("li");
  moreElement.id = "limore";
  var aMoreElement = document.createElement("a");
  aMoreElement.href = "javascript:void(0);";
  aMoreElement.innerText = "更多";
  moreElement.addEventListener("mouseover", function(e) {
    moreMenu.classList.remove("hidden");
  });
  moreElement.addEventListener("mousemove", function(e) {
    moreMenu.classList.remove("hidden");
  });
  moreElement.onclick = function() {
    moreMenu.classList.remove("hidden");
  };
  moreElement.appendChild(aMoreElement);

  topMenu.appendChild(moreElement);

  if (localStorage["picLastType"] && localStorage["picLastType"] != 0) {
    if (!isNaN(localStorage["picLastType"])) {
      getPicListByTypeID(localStorage["picLastType"]);
      for (var j = 0; j < dataLen; j++) {
        if (localStorage["picLastType"] == typeList[j].id) {
          var liList = document.querySelectorAll("#topmenu li");
          if (j >= moreCount) {
            setTimeout(function() {
              moreMenu.classList.remove("hidden");
            }, 100);
            liList[moreCount + 1].classList.add("menu_active");
            liList[j + 2].classList.add("menu_active");
          } else {
            liList[j].classList.add("menu_active");
          }
          break;
        }
      }
    } else if (localStorage["picLastType"] == "o") {
      $("wrapperHistory").classList.add("menu_active");
      getWrapperHistory();
    } else if (localStorage["picLastType"] == "p") {
      // personalElement.classList.add("menu_active");
      // var curTime = +new Date();
      // var personalData = null;
      // if (localStorage["personalCache"]) personalData = JSON.parse(localStorage["personalCache"]);
      // if (!personalData || !personalData.data || (curTime - parseFloat(personalData.lastTime)) > PWRAPPER_DATA_CACHE_EXPIRATION)
      //   getPersonalWrapper();
      // else {
      //   var personalCache = JSON.parse(localStorage['personalCache']);
      //   loadPersonalWrapper(personalCache.data);
      // }
    }
  } else {
    // getPicListByTypeID(0);
    // var liList = document.querySelectorAll("#topmenu li");
    // liList[0].classList.add("menu_active");
  }
}

function wallpaperInfo(info) {
  //console.log(info);
  clearTimeout(wrapperTimeOut);
  errorClose();
  if (!info) {
    var imglist = $("imglist");
    imglist.innerHTML = "<span>与服务器连接失败，无法获取图片。<br>请检查网络连接。</span>";
    imglist.classList.add("error");
  }
  var dataList = JSON.parse(info).data;
  if (!dataList || !dataList.length) {
    return;
  }
  var dataLen = dataList.length;
  var typeTag = dataList[0].url;
  if (typeTag) { //image list
    if ($('wrapperHistory').classList.contains('menu_active') || $("lipersonal").classList.contains('menu_active')) return; //fix bug
    var imglistDiv = document.querySelector("#imglist");
    var imgContainer = getImgContainers();
    var imgContainerLen = imgContainer.length;
    var imgTips = document.createElement("span");
    imgTips.className = "imgTips";
    imgTips.innerHTML = "<a class='skin_set'>设为壁纸</a><a title='设为桌面壁纸' class='wp_set'></a>";
    var imgParentDiv = document.createElement("div");

    var j = 0;
    for (var i = 0; i < imgContainerLen; i++) {
      if (j >= dataLen) break;
      if (imgContainer[i].classList.contains("c1")) {
        var imgdiv1 = imgParentDiv.cloneNode(true);
        var imgTip1 = imgTips.cloneNode(true);
        imgdiv1.appendChild(createImgWithInfo(dataList[j], "c1"));
        imgdiv1.appendChild(imgTip1);
        imgContainer[i].appendChild(imgdiv1);
        j++;
        if (j >= dataLen) break;
        else {
          var imgdiv2 = imgParentDiv.cloneNode(true);
          var imgTip2 = imgTips.cloneNode(true);
          imgdiv2.appendChild(createImgWithInfo(dataList[j], "c1"));
          imgdiv2.appendChild(imgTip2);
          imgContainer[i].appendChild(imgdiv2);
        }
      } else if (imgContainer[i].classList.contains("c2")) {
        var imgTip3 = imgTips.cloneNode(true);
        var wSet = imgTip3.querySelector(".wp_set");
        wSet.innerText = "设为桌面";
        imgTip3.appendChild(wSet);
        imgContainer[i].appendChild(createImgWithInfo(dataList[j], "c2"));
        imgContainer[i].appendChild(imgTip3);
      }
      j++;
      imglistDiv.appendChild(imgContainer[i]);
    }
  } else { //type list
    loadPicTypes(dataList);
    localStorage['picTypeList_lastTime'] = +new Date();
    localStorage["picTypeList"] = info;
  }
}

String.prototype.trim = function() {
  var str = this,
    str = str.replace(/^\s\s*/, ''),
    ws = /\s/,
    i = str.length;
  while (ws.test(str.charAt(--i)));
  return str.slice(0, i + 1);
}
String.prototype.xssFilter = function() {
  var str = this;
  if (typeof(str) == "string") {
    str = str.substring(0, 200);

    str = str.replace(/&/g, "&amp;");
    /* must do &amp; first */
    str = str.replace(/"/g, "&quot;");
    str = str.replace(/'/g, "&#039;");
    str = str.replace(/</g, "&lt;");
    str = str.replace(/>/g, "&gt;");
    str = str.replace(/@/g, "&#64;");
  }
  return str.toString();
}

NodeList.prototype.foreach = Array.prototype.forEach;